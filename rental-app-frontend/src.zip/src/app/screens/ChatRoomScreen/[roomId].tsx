import React, { useEffect, useRef } from "react";
import { FlatList, KeyboardAvoidingView, Platform } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { YStack, Spinner } from "tamagui";
import { useChat } from "../../../hooks/useChat";
import MessageBubble from "../../../components/chat/MessageBubble";
import MessageInput from "../../../components/chat/MessageInput";
import ChatHeader from "../../../components/chat/ChatHeader";

export default function ChatRoomScreen() {
  // Properly typed params
  const { roomId } = useLocalSearchParams<{ roomId: string }>();
  const { messages, sendMessage, isLoading, error } = useChat(roomId);
  const flatListRef = useRef<FlatList>(null);

  useEffect(() => {
    if (messages.length > 0) {
      flatListRef.current?.scrollToEnd({ animated: true });
    }
  }, [messages]);

  if (isLoading) {
    return (
      <YStack flex={1} justifyContent="center" alignItems="center">
        <Spinner size="large" color="$blue10" />
      </YStack>
    );
  }

  if (error) {
    return (
      <YStack flex={1} justifyContent="center" alignItems="center">
        <Text color="$red10">{error}</Text>
      </YStack>
    );
  }

  return (
  
    <YStack flex={1} backgroundColor="$background">
      <ChatHeader roomId={roomId as string} />
      
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
      >
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => item._id}
          contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }) => (
            <MessageBubble 
              message={item} 
              isCurrentUser={item.sender_id._id === currentUser?._id} 
            />
          )}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd()}
        />

        <MessageInput onSend={(content) => sendMessage({ content, room_id: roomId as string })} />
      </KeyboardAvoidingView>
    </YStack>
  );
};

export default ChatRoomScreen;