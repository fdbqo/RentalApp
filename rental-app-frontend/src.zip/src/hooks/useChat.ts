import { useEffect, useCallback } from 'react';
import { useChatStore } from '../store/chat.store';
import { wsService } from '../services/websocket.service';
import { SendMessagePayload } from '../store/interfaces/Chat';
import { useUserStore } from '../store/user.store'; // Assuming you have this

export const useChat = (roomId?: string) => {
  const {
    messages,
    rooms,
    currentRoomId,
    isLoading,
    error,
    setCurrentRoom,
    setMessages,
  } = useChatStore();
  
  const token = useUserStore(state => state.token);

  useEffect(() => {
    if (token) {
      wsService.connect(token);
    }
    
    return () => {
      wsService.disconnect();
    };
  }, [token]);

  useEffect(() => {
    if (roomId) {
      setCurrentRoom(roomId);
      wsService.joinRoom(roomId);
      // Fetch previous messages
      fetchMessages(roomId);
    }
  }, [roomId]);

  const fetchMessages = async (roomId: string) => {
    try {
      const response = await fetch(`http://localhost:3000/rooms/${roomId}/chats`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (!response.ok) throw new Error('Failed to fetch messages');
      
      const messages = await response.json();
      setMessages(messages);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const sendMessage = useCallback(async (payload: SendMessagePayload) => {
    wsService.sendMessage(payload.content, payload.room_id);
  }, []);

  return {
    messages,
    rooms,
    currentRoomId,
    isLoading,
    error,
    sendMessage,
    setCurrentRoom,
  };
};