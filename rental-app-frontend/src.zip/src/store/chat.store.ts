import { create } from 'zustand';
import { Message, Chat, SendMessagePayload } from './interfaces/Chat';
import { Room, CreateRoomPayload } from './interfaces/Room';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface ChatStore extends Chat {
  // Message actions
  setMessages: (messages: Message[]) => void;
  addMessage: (message: Message) => void;
  sendMessage: (payload: SendMessagePayload) => Promise<void>;
  
  // Room actions
  rooms: Room[];
  setRooms: (rooms: Room[]) => void;
  addRoom: (room: Room) => void;
  createRoom: (payload: CreateRoomPayload) => Promise<Room>;
  fetchRooms: () => Promise<void>;
  
  // UI state actions
  setCurrentRoom: (roomId: string) => void;
  setLoading: (isLoading: boolean) => void;
  setError: (error: string | null) => void;

  // WebSocket actions
  socket: WebSocket | null;
  connect: () => void;
  disconnect: () => void;
}

export const useChatStore = create<ChatStore>((set, get) => ({
  // Initial state
  messages: [],
  rooms: [],
  isLoading: false,
  error: null,
  currentRoomId: null,
  socket: null,

  // Message actions
  setMessages: (messages) => set({ messages }),
  addMessage: (message) => set((state) => ({ 
    messages: [...state.messages, message],
    rooms: state.rooms.map(room => 
      room._id === message.room_id 
        ? {
            ...room,
            lastMessage: {
              content: message.content,
              createdAt: message.createdAt
            }
          }
        : room
    )
  })),
  
  sendMessage: async (payload) => {
    const { socket } = get();
    if (!socket) throw new Error('WebSocket not connected');

    try {
      set({ isLoading: true, error: null });
      socket.send(JSON.stringify({
        event: 'create',
        data: payload
      }));
      set({ isLoading: false });
    } catch (error) {
      set({ error: 'Failed to send message', isLoading: false });
    }
  },

  // Room actions
  setRooms: (rooms) => set({ rooms }),
  addRoom: (room) => set((state) => ({ rooms: [...state.rooms, room] })),
  
  fetchRooms: async () => {
    try {
      set({ isLoading: true, error: null });
      const response = await fetch('http://localhost:3000/rooms', {
        headers: {
          'Authorization': `Bearer ${AsyncStorage.getItem('token')}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch rooms');
      }

      const rooms = await response.json();
      set({ rooms, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to fetch rooms', isLoading: false });
      throw error;
    }
  },

  createRoom: async (payload) => {
    try {
      set({ isLoading: true, error: null });
      const response = await fetch('http://localhost:3000/rooms', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // We'll need to add authorization header here
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error('Failed to create room');
      }

      const room = await response.json();
      get().addRoom(room);
      set({ isLoading: false });
      return room;
    } catch (error) {
      set({ error: 'Failed to create room', isLoading: false });
      throw error;
    }
  },

  // UI state actions
  setCurrentRoom: (roomId) => set({ currentRoomId: roomId }),
  setLoading: (isLoading) => set({ isLoading }),
  setError: (error) => set({ error }),

  // WebSocket actions
  connect: () => {
    const token = localStorage.getItem('token');
    if (!token) return;

    const ws = new WebSocket('ws://localhost:3000');
    
    ws.onopen = () => {
      // Add authorization header to the WebSocket handshake
      ws.send(JSON.stringify({
        event: 'auth',
        data: { token }
      }));
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      switch (data.event) {
        case 'new-chat':
          get().addMessage(data.data);
          break;
        // Add other event handlers as needed
      }
    };

    ws.onclose = (event) => {
      console.log('WebSocket closed:', event.code, event.reason);
      set({ socket: null });
      // Implement reconnection logic if needed
    };

    set({ socket: ws });
  },

  disconnect: () => {
    const { socket } = get();
    if (socket) {
      socket.close();
      set({ socket: null });
    }
  }
}));