import { Message } from '../store/interfaces/Chat';
import { useChatStore } from '../store/chat.store';

class WebSocketService {
  private socket: WebSocket | null = null;
  private readonly url = 'ws://localhost:3000'; // Update with your WebSocket URL

  connect(token: string) {
    if (this.socket?.readyState === WebSocket.OPEN) return;

    this.socket = new WebSocket(this.url);
    
    // Add authorization header
    this.socket.onopen = () => {
      console.log('WebSocket Connected');
      if (this.socket) {
        this.socket.send(JSON.stringify({
          event: 'auth',
          data: { token }
        }));
      }
    };

    this.socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      this.handleMessage(data);
    };

    this.socket.onerror = (error) => {
      console.error('WebSocket Error:', error);
      useChatStore.getState().setError('WebSocket connection error');
    };

    this.socket.onclose = () => {
      console.log('WebSocket Disconnected');
      // Implement reconnection logic here if needed
      setTimeout(() => this.connect(token), 5000);
    };
  }

  private handleMessage(data: any) {
    const { event, data: payload } = data;

    switch (event) {
      case 'new-chat':
        useChatStore.getState().addMessage(payload as Message);
        break;
      case 'joined':
        console.log('Joined room:', payload);
        break;
      case 'error':
        useChatStore.getState().setError(payload);
        break;
      default:
        console.log('Unhandled event:', event);
    }
  }

  joinRoom(roomId: string) {
    if (this.socket?.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify({
        event: 'join',
        data: roomId
      }));
    }
  }

  sendMessage(content: string, roomId: string) {
    if (this.socket?.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify({
        event: 'create',
        data: {
          room_id: roomId,
          content
        }
      }));
    }
  }

  disconnect() {
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
  }
}

export const wsService = new WebSocketService();